# services/storage_service.py - In-Memory Storage (No MongoDB)
from database import get_collection
from datetime import datetime
import uuid

async def save_output(collection_name: str, module: str, input_data: dict, output: str, metadata: dict = {}):
    collection = get_collection(collection_name)
    doc = {
        "_id": str(uuid.uuid4()),
        "module": module,
        "input": input_data,
        "output": output,
        "metadata": metadata,
        "created_at": datetime.utcnow().isoformat(),
    }
    collection.append(doc)
    return doc["_id"]

async def get_history(collection_name: str, limit: int = 10, module: str = None):
    collection = get_collection(collection_name)
    results = [d for d in collection if module is None or d.get("module") == module]
    return list(reversed(results))[:limit]

async def get_by_id(collection_name: str, doc_id: str):
    collection = get_collection(collection_name)
    return next((d for d in collection if d["_id"] == doc_id), None)

async def delete_by_id(collection_name: str, doc_id: str):
    col = get_collection(collection_name)
    before = len(col)
    col[:] = [d for d in col if d["_id"] != doc_id]
    return len(col) < before

async def get_analytics_summary():
    collections = ["campaigns", "pitches", "leads", "market_analysis",
                   "personas", "reports", "predictions", "competitive_intel",
                   "strategies", "multimodal"]
    summary = {}
    for col in collections:
        docs = get_collection(col)
        summary[col] = {
            "total_outputs": len(docs),
            "last_used": docs[-1]["created_at"] if docs else None
        }
    return summary
