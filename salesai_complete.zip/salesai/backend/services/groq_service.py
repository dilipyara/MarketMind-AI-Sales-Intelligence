# services/groq_service.py - Core Groq AI Service
from groq import Groq
from config import settings
import json
import re

client = Groq(api_key=settings.GROQ_API_KEY)

SYSTEM_PROMPT = """You are an advanced Generative AI Sales and Marketing Intelligence Assistant designed for business teams. 
You specialize in marketing strategy generation, sales enablement, lead intelligence, market analysis, and business insights.
Generate clear, actionable, data-driven, and human-like outputs tailored for business decision-makers.
Always use clear headings (##), bullet points (-), and professional language.
Provide specific, actionable recommendations. Avoid generic advice."""

async def generate_ai_response(
    user_prompt: str,
    system_override: str = None,
    temperature: float = 0.7,
    max_tokens: int = 2048
) -> str:
    """Core function to call Groq API"""
    try:
        response = client.chat.completions.create(
            model=settings.GROQ_MODEL,
            messages=[
                {
                    "role": "system",
                    "content": system_override or SYSTEM_PROMPT
                },
                {
                    "role": "user",
                    "content": user_prompt
                }
            ],
            temperature=temperature,
            max_tokens=max_tokens,
        )
        return response.choices[0].message.content
    except Exception as e:
        raise Exception(f"Groq API Error: {str(e)}")


async def generate_structured_json(prompt: str, schema_hint: str = "") -> dict:
    """Generate structured JSON response from Groq"""
    json_prompt = f"""{prompt}

IMPORTANT: Respond ONLY with valid JSON. No markdown, no explanation, no code blocks.
{schema_hint}"""
    
    try:
        response = client.chat.completions.create(
            model=settings.GROQ_MODEL,
            messages=[
                {"role": "system", "content": "You are a data analyst. Always respond with valid JSON only."},
                {"role": "user", "content": json_prompt}
            ],
            temperature=0.3,
            max_tokens=1500,
        )
        raw = response.choices[0].message.content.strip()
        # Clean up JSON if wrapped in markdown
        raw = re.sub(r'^```json\s*', '', raw)
        raw = re.sub(r'\s*```$', '', raw)
        return json.loads(raw)
    except json.JSONDecodeError:
        return {"raw_response": response.choices[0].message.content}
    except Exception as e:
        raise Exception(f"Groq JSON Error: {str(e)}")
