# models/schemas.py - Pydantic Request/Response Models
from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any
from enum import Enum

class BuyingStage(str, Enum):
    awareness = "awareness"
    consideration = "consideration"
    decision = "decision"
    retention = "retention"

class IndustryType(str, Enum):
    saas = "SaaS"
    ecommerce = "E-Commerce"
    fintech = "FinTech"
    healthcare = "Healthcare"
    retail = "Retail"
    manufacturing = "Manufacturing"
    education = "Education"
    real_estate = "Real Estate"
    other = "Other"

# ─── Campaign Generation ──────────────────────────────────────────────────────
class CampaignRequest(BaseModel):
    product_name: str = Field(..., example="AI-Powered CRM Software")
    target_audience: str = Field(..., example="Mid-size tech companies, VP Sales")
    industry: str = Field(..., example="SaaS")
    business_goals: str = Field(..., example="Increase trial signups by 30%")
    customer_intent: Optional[str] = Field(None, example="Looking for automation solutions")
    campaign_type: Optional[str] = Field("full", example="email/social/ad/full")

# ─── Sales Pitch ─────────────────────────────────────────────────────────────
class PitchRequest(BaseModel):
    product_name: str = Field(..., example="CloudSecure Platform")
    customer_name: Optional[str] = Field(None, example="John Smith")
    company_name: Optional[str] = Field(None, example="TechCorp Inc.")
    pain_points: str = Field(..., example="Security breaches, compliance issues")
    buying_stage: BuyingStage = Field(BuyingStage.consideration)
    pitch_type: Optional[str] = Field("all", example="cold_call/demo/email/all")

# ─── Lead Scoring ─────────────────────────────────────────────────────────────
class LeadRequest(BaseModel):
    lead_name: str = Field(..., example="Sarah Johnson")
    company: str = Field(..., example="FinEdge Corp")
    role: str = Field(..., example="Director of Marketing")
    company_size: Optional[str] = Field(None, example="200-500 employees")
    interactions: Optional[str] = Field(None, example="Opened 5 emails, visited pricing page 3 times")
    budget_indicated: Optional[bool] = Field(None)
    timeline: Optional[str] = Field(None, example="Q3 purchase")
    industry: Optional[str] = Field(None, example="FinTech")

# ─── Market Analysis ──────────────────────────────────────────────────────────
class MarketRequest(BaseModel):
    industry: str = Field(..., example="B2B SaaS HR Automation")
    region: Optional[str] = Field("Global", example="North America")
    company_context: Optional[str] = Field(None, example="Early-stage startup")
    competitors_mentioned: Optional[str] = Field(None, example="Workday, BambooHR")

# ─── Business Strategy ────────────────────────────────────────────────────────
class StrategyRequest(BaseModel):
    company_name: str = Field(..., example="GrowthScale Inc.")
    current_revenue: Optional[str] = Field(None, example="$2M ARR")
    growth_target: Optional[str] = Field(None, example="Reach $5M ARR in 12 months")
    challenges: str = Field(..., example="High churn, low enterprise conversion")
    industry: Optional[str] = Field(None, example="SaaS")

# ─── Customer Persona ─────────────────────────────────────────────────────────
class PersonaRequest(BaseModel):
    product_name: str = Field(..., example="AI Marketing Platform")
    industry: str = Field(..., example="Digital Marketing Agency")
    target_segment: Optional[str] = Field(None, example="SMBs and Mid-market")
    num_personas: Optional[int] = Field(2, ge=1, le=4)

# ─── Performance Report ──────────────────────────────────────────────────────
class ReportRequest(BaseModel):
    period: str = Field(..., example="July 2025")
    report_type: str = Field("monthly", example="weekly/monthly")
    revenue: Optional[str] = Field(None, example="$1.2M")
    target_revenue: Optional[str] = Field(None, example="$1.5M")
    leads_generated: Optional[int] = Field(None, example=340)
    conversion_rate: Optional[str] = Field(None, example="22%")
    top_channel: Optional[str] = Field(None, example="Email, LinkedIn")
    additional_data: Optional[str] = Field(None, example="Churn rate 5%, NPS 42")

# ─── Predictive Insights ─────────────────────────────────────────────────────
class PredictRequest(BaseModel):
    company_context: str = Field(..., example="E-commerce fashion brand")
    current_metrics: Optional[str] = Field(None, example="15% MoM growth, 10K customers")
    market_context: Optional[str] = Field(None, example="Holiday season approaching")
    prediction_horizon: Optional[str] = Field("90 days", example="30/60/90 days")

# ─── Competitive Intel ───────────────────────────────────────────────────────
class CompeteRequest(BaseModel):
    your_product: str = Field(..., example="AI Writing Assistant")
    competitors: Optional[str] = Field(None, example="Jasper, Copy.ai, Writesonic")
    your_strengths: Optional[str] = Field(None, example="Better accuracy, lower price")
    target_market: Optional[str] = Field(None, example="SMBs and freelancers")

# ─── Multimodal Content ──────────────────────────────────────────────────────
class MultimodalRequest(BaseModel):
    product_name: str = Field(..., example="NextGen CRM")
    campaign_theme: Optional[str] = Field(None, example="Productivity & Automation")
    target_audience: Optional[str] = Field(None, example="Sales managers, 30-45 years old")
    platform: Optional[str] = Field("all", example="linkedin/instagram/youtube/all")

# ─── Generic Response ────────────────────────────────────────────────────────
class AIResponse(BaseModel):
    success: bool
    module: str
    output: str
    record_id: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None

class LeadScoreResponse(BaseModel):
    success: bool
    module: str = "lead_scoring"
    score: int
    priority: str
    conversion_probability: str
    reasoning: str
    next_actions: List[str]
    output: str
    record_id: Optional[str] = None
