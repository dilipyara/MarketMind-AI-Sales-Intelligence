# routes/campaign.py
from fastapi import APIRouter, HTTPException
from models.schemas import CampaignRequest, AIResponse
from services.groq_service import generate_ai_response
from services.storage_service import save_output, get_history

router = APIRouter()

@router.post("/generate", response_model=AIResponse)
async def generate_campaign(req: CampaignRequest):
    prompt = f"""Generate a complete, end-to-end marketing campaign for the following:

**Product/Service:** {req.product_name}
**Target Audience:** {req.target_audience}
**Industry:** {req.industry}
**Business Goals:** {req.business_goals}
**Customer Intent:** {req.customer_intent or 'Not specified'}
**Campaign Type:** {req.campaign_type}

Generate the following sections:

## 1. Campaign Overview & Theme
- Campaign name and tagline
- Core message and value proposition
- Campaign objectives

## 2. Email Marketing Campaign
- Subject line (A/B test: provide 2 options)
- Preview text
- Full email body (professional, persuasive, 3 paragraphs)
- CTA (Call-to-Action)

## 3. Social Media Content
- **LinkedIn Post** (professional, 150 words)
- **Twitter/X Post** (engaging, under 280 chars with hashtags)
- **Instagram Caption** (visual-focused, with hashtags)

## 4. Ad Copy & Slogans
- Google Search Ad (headline + description)
- Facebook/Meta Ad copy (short form)
- 3 punchy slogans

## 5. Campaign KPIs to Track
- 5 measurable success metrics

Make it specific, compelling, and action-oriented."""

    try:
        output = await generate_ai_response(prompt)
        record_id = await save_output("campaigns", "campaign_generation", req.dict(), output)
        return AIResponse(success=True, module="campaign_generation", output=output, record_id=record_id)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/history")
async def get_campaign_history(limit: int = 10):
    return await get_history("campaigns", limit, "campaign_generation")
