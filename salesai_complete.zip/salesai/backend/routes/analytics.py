# routes/analytics.py - Additional Feature: Usage Analytics Dashboard
from fastapi import APIRouter, HTTPException
from services.storage_service import get_analytics_summary, get_history
from database import get_collection
from datetime import datetime, timedelta

router = APIRouter()

@router.get("/summary")
async def get_analytics():
    """Get platform-wide usage analytics"""
    try:
        summary = await get_analytics_summary()
        total_outputs = sum(v["total_outputs"] for v in summary.values())
        most_used = max(summary.items(), key=lambda x: x[1]["total_outputs"])[0] if total_outputs > 0 else "N/A"

        return {
            "success": True,
            "total_ai_outputs_generated": total_outputs,
            "most_used_module": most_used,
            "module_breakdown": summary,
            "platform_status": "operational"
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/recent")
async def get_recent_activity(limit: int = 20):
    """Get recent activity across all modules"""
    collections = {
        "campaigns": "Campaign Generation",
        "pitches": "Sales Pitch",
        "leads": "Lead Scoring",
        "market_analysis": "Market Analysis",
        "personas": "Customer Persona",
        "reports": "Performance Report",
        "predictions": "Predictive Insights",
        "competitive_intel": "Competitive Intel",
        "strategies": "Business Strategy",
        "multimodal": "Multimodal Content"
    }

    recent = []
    for col, label in collections.items():
        history = await get_history(col, 3)
        for item in history:
            recent.append({
                "module": label,
                "collection": col,
                "id": item.get("_id"),
                "created_at": item.get("created_at"),
                "input_preview": str(item.get("input", {}))[:100]
            })

    recent.sort(key=lambda x: x.get("created_at") or "", reverse=True)
    return {"success": True, "recent_activity": recent[:limit]}
