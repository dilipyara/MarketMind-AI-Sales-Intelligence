# routes/lead.py
from fastapi import APIRouter, HTTPException
from models.schemas import LeadRequest, LeadScoreResponse
from services.groq_service import generate_ai_response, generate_structured_json
from services.storage_service import save_output, get_history
import re

router = APIRouter()

@router.post("/score", response_model=LeadScoreResponse)
async def score_lead(req: LeadRequest):
    # First: get structured score
    score_prompt = f"""Analyze this lead and return a JSON object:

Lead Info:
- Name: {req.lead_name}
- Company: {req.company}
- Role: {req.role}
- Company Size: {req.company_size or 'Unknown'}
- Interactions: {req.interactions or 'No data'}
- Budget Indicated: {req.budget_indicated}
- Purchase Timeline: {req.timeline or 'Unknown'}
- Industry: {req.industry or 'Unknown'}

Return JSON with these exact keys:
{{
  "score": <integer 0-100>,
  "priority": "<High|Medium|Low>",
  "conversion_probability": "<percentage like 75%>",
  "next_actions": ["action1", "action2", "action3"],
  "reasoning": "<2-3 sentence explanation>"
}}"""

    schema_hint = 'Return only: {"score": int, "priority": str, "conversion_probability": str, "next_actions": [str], "reasoning": str}'

    # Full narrative output
    narrative_prompt = f"""Generate a comprehensive lead intelligence report for:

**Lead:** {req.lead_name}, {req.role} at {req.company}
**Company Size:** {req.company_size or 'Unknown'}
**Interactions:** {req.interactions or 'No recorded interactions'}
**Budget Indicated:** {'Yes' if req.budget_indicated else 'No/Unknown'}
**Timeline:** {req.timeline or 'Not specified'}
**Industry:** {req.industry or 'Not specified'}

## Lead Intelligence Report

### Lead Profile Summary
- Who they are and why they matter

### Buying Signals Detected
- List all positive and negative signals

### Priority Assessment
- High/Medium/Low with detailed reasoning

### Conversion Probability Analysis
- Probability estimate with supporting factors

### Recommended Next Actions (Prioritized)
1. Immediate action (within 24 hours)
2. Short-term action (this week)
3. Long-term nurture strategy

### Risk Factors
- Potential blockers to conversion

### Personalization Tips
- How to approach this specific lead"""

    try:
        structured = await generate_structured_json(score_prompt, schema_hint)
        narrative = await generate_ai_response(narrative_prompt)

        score = structured.get("score", 50)
        priority = structured.get("priority", "Medium")
        conversion = structured.get("conversion_probability", "50%")
        next_actions = structured.get("next_actions", ["Follow up via email", "Schedule a demo", "Send case study"])
        reasoning = structured.get("reasoning", "Unable to determine reasoning.")

        record_id = await save_output("leads", "lead_scoring", req.dict(), narrative, {
            "score": score, "priority": priority, "conversion_probability": conversion
        })

        return LeadScoreResponse(
            success=True,
            score=score,
            priority=priority,
            conversion_probability=conversion,
            reasoning=reasoning,
            next_actions=next_actions,
            output=narrative,
            record_id=record_id
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/history")
async def get_lead_history(limit: int = 10):
    return await get_history("leads", limit, "lead_scoring")
