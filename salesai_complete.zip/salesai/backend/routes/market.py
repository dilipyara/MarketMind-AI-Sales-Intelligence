# routes/market.py
from fastapi import APIRouter, HTTPException
from models.schemas import MarketRequest, AIResponse
from services.groq_service import generate_ai_response
from services.storage_service import save_output, get_history

router = APIRouter()

@router.post("/analyze", response_model=AIResponse)
async def analyze_market(req: MarketRequest):
    prompt = f"""Perform a comprehensive market analysis for:

**Industry/Market:** {req.industry}
**Region:** {req.region}
**Company Context:** {req.company_context or 'Not specified'}
**Known Competitors:** {req.competitors_mentioned or 'Not specified'}

## Market Analysis Report

### Executive Summary
- 3-sentence overview of the market landscape

### Current Market Trends (Top 5)
- Each trend with business impact explanation

### Emerging Opportunities
- 3 specific opportunities to capitalize on now

### Market Risks & Threats
- Key threats with mitigation strategies

### Customer Demand Shifts
- How buyer behavior is changing

### Market Size & Growth Indicators
- Estimated market dynamics (qualitative)

### Strategic Entry/Growth Recommendations
- 4 actionable strategies for this market

### Quick Wins (0-90 days)
- Immediate actions to gain market traction

Use simple, business-friendly language. Be specific, not generic."""

    try:
        output = await generate_ai_response(prompt)
        record_id = await save_output("market_analysis", "market_analysis", req.dict(), output)
        return AIResponse(success=True, module="market_analysis", output=output, record_id=record_id)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/history")
async def get_market_history(limit: int = 10):
    return await get_history("market_analysis", limit, "market_analysis")
