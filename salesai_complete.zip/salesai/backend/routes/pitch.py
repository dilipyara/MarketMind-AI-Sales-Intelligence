# routes/pitch.py
from fastapi import APIRouter, HTTPException
from models.schemas import PitchRequest, AIResponse
from services.groq_service import generate_ai_response
from services.storage_service import save_output, get_history

router = APIRouter()

@router.post("/generate", response_model=AIResponse)
async def generate_pitch(req: PitchRequest):
    prompt = f"""Generate personalized sales pitches for the following:

**Product:** {req.product_name}
**Customer:** {req.customer_name or 'Prospect'} at {req.company_name or 'their company'}
**Key Pain Points:** {req.pain_points}
**Buying Stage:** {req.buying_stage}
**Pitch Type Needed:** {req.pitch_type}

Generate the following:

## 1. Cold Call Script (60-Second Opener)
- Opening hook (attention-grabbing, personalized)
- Pain point identification
- Value proposition (1-2 sentences)
- Soft CTA (schedule a demo/call)
- Handling "I'm busy" objection

## 2. Email Outreach
- Subject line (curiosity-driven)
- Opening (personalized to their role/company)
- Body (problem → solution → proof → CTA)
- Signature block suggestion

## 3. Product Demo Talking Points
- Opening narrative (set the stage)
- 5 key features to highlight (tied to their pain points)
- ROI/business impact statements
- Demo closing technique

## 4. Objection Handling Guide
- Top 5 likely objections with scripted responses

## 5. Follow-Up Sequence
- Day 1, Day 3, Day 7 follow-up message ideas

Adapt tone based on buying stage ({req.buying_stage}) — be consultative, not pushy."""

    try:
        output = await generate_ai_response(prompt)
        record_id = await save_output("pitches", "sales_pitch", req.dict(), output)
        return AIResponse(success=True, module="sales_pitch", output=output, record_id=record_id)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/history")
async def get_pitch_history(limit: int = 10):
    return await get_history("pitches", limit, "sales_pitch")
