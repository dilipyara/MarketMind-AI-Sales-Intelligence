# routes/persona.py
from fastapi import APIRouter, HTTPException
from models.schemas import PersonaRequest, AIResponse
from services.groq_service import generate_ai_response
from services.storage_service import save_output, get_history

router = APIRouter()

@router.post("/generate", response_model=AIResponse)
async def generate_persona(req: PersonaRequest):
    prompt = f"""Generate {req.num_personas} detailed, realistic customer personas for:

**Product:** {req.product_name}
**Industry:** {req.industry}
**Target Segment:** {req.target_segment or 'Not specified'}

For EACH persona, include:

## Persona [Number]: [Persona Name]

### 👤 Profile Snapshot
- Age, Gender, Location
- Job Title & Industry
- Company Size & Annual Revenue
- Income Range

### 🎯 Goals & Motivations
- Primary professional goal
- What success looks like for them
- Personal motivations

### 😤 Pain Points & Frustrations
- Top 3 daily challenges
- What keeps them up at night
- Current solution gaps

### 🛒 Buying Behavior
- Decision-making process
- Budget authority level
- Key buying triggers
- Deal-breakers

### 📱 Preferred Communication Channels
- How they like to be reached
- Content they consume
- Social platforms they use

### 💬 Their Voice (Direct Quote)
- A quote that captures their mindset

### 🎯 How to Win Them
- Messaging that resonates
- Content that converts
- Sales approach that works

Make them feel like real, specific people — not generic archetypes."""

    try:
        output = await generate_ai_response(prompt)
        record_id = await save_output("personas", "customer_persona", req.dict(), output)
        return AIResponse(success=True, module="customer_persona", output=output, record_id=record_id)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/history")
async def get_persona_history(limit: int = 10):
    return await get_history("personas", limit, "customer_persona")
