# routes/predict.py
from fastapi import APIRouter, HTTPException
from models.schemas import PredictRequest, AIResponse
from services.groq_service import generate_ai_response
from services.storage_service import save_output, get_history

router = APIRouter()

@router.post("/generate", response_model=AIResponse)
async def generate_predictions(req: PredictRequest):
    prompt = f"""Generate data-driven predictive business insights for:

**Company Context:** {req.company_context}
**Current Metrics:** {req.current_metrics or 'Not provided'}
**Market Context:** {req.market_context or 'Not provided'}
**Prediction Horizon:** {req.prediction_horizon}

## Predictive Intelligence Report

### 📌 Key Assumptions
- List all assumptions used for predictions

### 📈 Sales Trend Forecast ({req.prediction_horizon})
- 30-day projection (with confidence level)
- 60-day projection
- 90-day projection
- Scenarios: Best case / Base case / Worst case

### 🎯 High-Potential Customer Segments
- Segment 1: Description + Why High Potential + How to Reach
- Segment 2: Description + Why High Potential + How to Reach
- Segment 3: Description + Why High Potential + How to Reach

### 📣 Campaign Performance Predictions
- Predicted best-performing channel (with reasoning)
- Predicted worst-performing channel (with reasoning)
- Expected conversion rate range
- Revenue impact estimate

### 💰 Revenue Opportunity Estimates
- Short-term opportunity (0-30 days)
- Mid-term opportunity (30-90 days)
- Confidence level for each

### ⚡ Early Warning Signals
- 3 signals that could indicate negative trends
- What to watch for

### 🎯 Recommended Proactive Actions
- Actions to take NOW to maximize predicted outcomes

Be specific and honest about confidence levels."""

    try:
        output = await generate_ai_response(prompt)
        record_id = await save_output("predictions", "predictive_insights", req.dict(), output)
        return AIResponse(success=True, module="predictive_insights", output=output, record_id=record_id)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/history")
async def get_predict_history(limit: int = 10):
    return await get_history("predictions", limit, "predictive_insights")
