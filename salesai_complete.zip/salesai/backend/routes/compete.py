# routes/compete.py
from fastapi import APIRouter, HTTPException
from models.schemas import CompeteRequest, AIResponse
from services.groq_service import generate_ai_response
from services.storage_service import save_output, get_history

router = APIRouter()

@router.post("/analyze", response_model=AIResponse)
async def analyze_competition(req: CompeteRequest):
    prompt = f"""Generate comprehensive competitive intelligence for:

**Your Product:** {req.your_product}
**Key Competitors:** {req.competitors or 'Top players in the market'}
**Your Strengths:** {req.your_strengths or 'Not specified'}
**Target Market:** {req.target_market or 'Not specified'}

## Competitive Intelligence Report

### 🏟️ Competitive Landscape Overview
- Market dynamics and key player summary

### 🔍 Competitor Analysis (per competitor)
For each competitor:
**[Competitor Name]**
- Positioning & messaging
- Target segment
- Key strengths
- Known weaknesses
- Pricing approach (if known)

### ⚔️ Differentiation Opportunities
- Where you can uniquely win
- Gaps competitors are leaving open
- Positioning white space

### 💬 Winning Messaging Strategy
- Headline messaging to use against each competitor
- Key differentiators to emphasize
- What NOT to say (messages that backfire)

### 🃏 Battle Cards (Quick Reference)
For each competitor:
| When prospect mentions them | Your response |
| Key objection | Winning counter |

### 🚀 Go-to-Market Positioning
- Recommended brand positioning statement
- 3 messaging pillars to own

### 📊 Competitive SWOT
- Your Strengths, Weaknesses, Opportunities, Threats vs. field

### 🎯 Win Strategy Summary
- Top 3 tactics to outperform competitors this quarter"""

    try:
        output = await generate_ai_response(prompt)
        record_id = await save_output("competitive_intel", "competitive_intel", req.dict(), output)
        return AIResponse(success=True, module="competitive_intel", output=output, record_id=record_id)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/history")
async def get_compete_history(limit: int = 10):
    return await get_history("competitive_intel", limit, "competitive_intel")
