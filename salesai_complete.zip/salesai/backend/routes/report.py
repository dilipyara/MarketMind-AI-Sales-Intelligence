# routes/report.py
from fastapi import APIRouter, HTTPException
from models.schemas import ReportRequest, AIResponse
from services.groq_service import generate_ai_response
from services.storage_service import save_output, get_history

router = APIRouter()

@router.post("/generate", response_model=AIResponse)
async def generate_report(req: ReportRequest):
    prompt = f"""Generate a professional {req.report_type} performance report for:

**Period:** {req.period}
**Revenue:** {req.revenue or 'Not provided'} (Target: {req.target_revenue or 'Not set'})
**Leads Generated:** {req.leads_generated or 'Not provided'}
**Conversion Rate:** {req.conversion_rate or 'Not provided'}
**Top Channel:** {req.top_channel or 'Not specified'}
**Additional Data:** {req.additional_data or 'None'}

## {req.report_type.title()} Performance Report — {req.period}

### 📊 Executive Summary
- 3-sentence snapshot of performance this period

### 🏆 Key Performance Indicators

| Metric | Actual | Target | Status |
|--------|--------|--------|--------|
[Fill with provided data, estimate where needed]

### ✅ Top Wins This Period
- 3-5 achievements with business impact

### ⚠️ Gaps & Underperformance Areas
- Areas falling short with root cause analysis

### 📈 Trend Analysis
- Period-over-period comparison
- Momentum indicators (accelerating/decelerating)

### 🔍 Channel Performance Breakdown
- Performance by channel with insights

### 💡 5 Actionable Improvement Recommendations
For each: Problem → Root Cause → Recommended Action → Expected Impact

### 🎯 Next Period Priorities
- Top 3 focus areas for the next reporting period

Format as a clean business report suitable for executive presentation."""

    try:
        output = await generate_ai_response(prompt)
        record_id = await save_output("reports", "performance_report", req.dict(), output)
        return AIResponse(success=True, module="performance_report", output=output, record_id=record_id)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/history")
async def get_report_history(limit: int = 10):
    return await get_history("reports", limit, "performance_report")
