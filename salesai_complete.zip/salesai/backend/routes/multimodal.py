# routes/multimodal.py
from fastapi import APIRouter, HTTPException
from models.schemas import MultimodalRequest, AIResponse
from services.groq_service import generate_ai_response
from services.storage_service import save_output, get_history

router = APIRouter()

@router.post("/generate", response_model=AIResponse)
async def generate_multimodal(req: MultimodalRequest):
    prompt = f"""Generate creative multimodal content suggestions for:

**Product:** {req.product_name}
**Campaign Theme:** {req.campaign_theme or 'Brand awareness and conversion'}
**Target Audience:** {req.target_audience or 'Business professionals'}
**Platform Focus:** {req.platform}

## Multimodal Content Strategy

### 🎨 Visual Ad Concepts

**Concept 1: Hero Image Ad**
- Visual description (colors, composition, mood)
- Text overlay
- CTA button
- Platform: Google Display / LinkedIn

**Concept 2: Product Spotlight Ad**
- Visual description
- Key message
- CTA
- Platform: Facebook / Instagram

**Concept 3: Testimonial/Social Proof Ad**
- Layout description
- Quote placement
- Visual elements
- Platform: LinkedIn / Twitter

### 🖼️ Banner Ad Ideas (Web & Display)
- Leaderboard (728x90): Description + copy
- Rectangle (300x250): Description + copy
- Skyscraper (160x600): Description + copy
- Mobile Banner (320x50): Description + copy

### 🎬 Short Video Script Ideas (Text Description)

**Video 1: Problem-Solution (30 seconds)**
- Scene-by-scene description
- Voiceover script
- On-screen text
- Music mood

**Video 2: Social Proof / Testimonial (20 seconds)**
- Visual flow description
- Key soundbites
- B-roll suggestions

**Video 3: Product Demo Teaser (15 seconds - Reels/Shorts)**
- Hook (first 3 seconds)
- Core message
- Closing CTA
- Text animations description

### 📧 Email Template Visual Layout
- Header design concept
- Body layout suggestion
- CTA button style
- Footer elements

### 🎯 Content Calendar Recommendations
- Best posting days/times per platform
- Content mix ratio (educational/promotional/social proof)"""

    try:
        output = await generate_ai_response(prompt)
        record_id = await save_output("multimodal", "multimodal_content", req.dict(), output)
        return AIResponse(success=True, module="multimodal_content", output=output, record_id=record_id)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/history")
async def get_multimodal_history(limit: int = 10):
    return await get_history("multimodal", limit, "multimodal_content")
