# routes/strategy.py
from fastapi import APIRouter, HTTPException
from models.schemas import StrategyRequest, AIResponse
from services.groq_service import generate_ai_response
from services.storage_service import save_output, get_history

router = APIRouter()

@router.post("/generate", response_model=AIResponse)
async def generate_strategy(req: StrategyRequest):
    prompt = f"""Generate a comprehensive business growth and revenue strategy for:

**Company:** {req.company_name}
**Current Revenue:** {req.current_revenue or 'Not specified'}
**Growth Target:** {req.growth_target or 'Not specified'}
**Key Challenges:** {req.challenges}
**Industry:** {req.industry or 'Not specified'}

## Business Strategy Report

### Situation Assessment
- Current state analysis based on provided data
- Gap between current state and target

### Growth Recommendations (Top 5)
- Each recommendation with: What → Why → How → Expected Impact

### Revenue Optimization Strategies
1. Pricing strategy optimization
2. Upsell/cross-sell opportunities
3. New revenue stream suggestions
4. Cost efficiency improvements

### Customer Retention Plan
- Churn reduction tactics
- Loyalty & engagement programs
- Customer success touchpoints

### 90-Day Action Roadmap
- Month 1: Foundation (Quick wins)
- Month 2: Acceleration (Build momentum)
- Month 3: Scale (Compound results)

### Key Metrics to Track
- 6 KPIs to measure strategy effectiveness

### Risk Mitigation
- Top 3 risks with mitigation plans"""

    try:
        output = await generate_ai_response(prompt)
        record_id = await save_output("strategies", "business_strategy", req.dict(), output)
        return AIResponse(success=True, module="business_strategy", output=output, record_id=record_id)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/history")
async def get_strategy_history(limit: int = 10):
    return await get_history("strategies", limit, "business_strategy")
