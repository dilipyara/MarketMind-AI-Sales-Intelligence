// src/pages/Dashboard.jsx
import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { analyticsAPI } from '../utils/api'
import { MODULES } from '../utils/moduleConfig'

export default function Dashboard() {
  const navigate = useNavigate()
  const [analytics, setAnalytics] = useState(null)
  const [recent, setRecent] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    Promise.all([analyticsAPI.summary(), analyticsAPI.recent(8)])
      .then(([sum, rec]) => {
        setAnalytics(sum)
        setRecent(rec.recent_activity || [])
      })
      .catch(() => {})
      .finally(() => setLoading(false))
  }, [])

  return (
    <div style={{ padding: '32px 36px', maxWidth: 1200 }}>
      {/* Hero */}
      <div style={{ marginBottom: 36 }}>
        <div style={{ fontSize: 28, fontWeight: 900, letterSpacing: -1, marginBottom: 8 }}>
          <span style={{ background: 'linear-gradient(90deg, #FF6B35, #7B61FF)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>
            GenAI Sales & Marketing
          </span>{' '}
          Intelligence
        </div>
        <p style={{ color: '#444', fontSize: 14, margin: 0 }}>
          Automate content creation · Score leads · Analyze markets · Drive growth
        </p>
      </div>

      {/* Stats Row */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16, marginBottom: 32 }}>
        {[
          { label: 'Total AI Outputs', value: analytics?.total_ai_outputs_generated ?? '—', color: '#FF6B35', icon: '⚡' },
          { label: 'Active Modules', value: MODULES.length, color: '#00D4AA', icon: '🧩' },
          { label: 'Most Used', value: analytics?.most_used_module?.replace(/_/g, ' ') ?? '—', color: '#7B61FF', icon: '🏆' },
          { label: 'Platform Status', value: 'Operational', color: '#4ECDC4', icon: '✅' },
        ].map((stat, i) => (
          <div key={i} style={{ background: '#0D0D1A', border: '1px solid #15152A', borderRadius: 14, padding: '20px 18px' }}>
            <div style={{ fontSize: 22, marginBottom: 8 }}>{stat.icon}</div>
            <div style={{ fontSize: 22, fontWeight: 800, color: stat.color }}>{stat.value}</div>
            <div style={{ fontSize: 11, color: '#444', marginTop: 4 }}>{stat.label}</div>
          </div>
        ))}
      </div>

      {/* Modules Grid */}
      <div style={{ marginBottom: 32 }}>
        <div style={{ fontSize: 13, fontWeight: 700, color: '#333', letterSpacing: 1.5, marginBottom: 16 }}>ALL MODULES</div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: 12 }}>
          {MODULES.map(m => (
            <button key={m.id} onClick={() => navigate(`/module/${m.id}`)}
              style={{
                background: '#0D0D1A', border: `1px solid #15152A`, borderRadius: 14,
                padding: '18px 14px', textAlign: 'left', cursor: 'pointer',
                transition: 'all 0.2s', color: '#fff',
              }}
              onMouseEnter={e => { e.currentTarget.style.borderColor = m.color + '55'; e.currentTarget.style.background = m.color + '08' }}
              onMouseLeave={e => { e.currentTarget.style.borderColor = '#15152A'; e.currentTarget.style.background = '#0D0D1A' }}
            >
              <div style={{ fontSize: 24, marginBottom: 10 }}>{m.icon}</div>
              <div style={{ fontSize: 12, fontWeight: 700, color: m.color, marginBottom: 4 }}>{m.label}</div>
              <div style={{ fontSize: 10, color: '#444', lineHeight: 1.5 }}>{m.description}</div>
            </button>
          ))}
        </div>
      </div>

      {/* Recent Activity */}
      {recent.length > 0 && (
        <div>
          <div style={{ fontSize: 13, fontWeight: 700, color: '#333', letterSpacing: 1.5, marginBottom: 16 }}>RECENT ACTIVITY</div>
          <div style={{ background: '#0D0D1A', border: '1px solid #15152A', borderRadius: 14, overflow: 'hidden' }}>
            {recent.map((r, i) => (
              <div key={i} style={{ padding: '12px 18px', borderBottom: i < recent.length - 1 ? '1px solid #111' : 'none', display: 'flex', alignItems: 'center', gap: 12 }}>
                <span style={{ fontSize: 14 }}>{MODULES.find(m => m.label === r.module)?.icon || '🤖'}</span>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 12, fontWeight: 600, color: '#aaa' }}>{r.module}</div>
                  <div style={{ fontSize: 11, color: '#444', marginTop: 2 }}>{r.input_preview}</div>
                </div>
                <div style={{ fontSize: 10, color: '#333' }}>{r.created_at ? new Date(r.created_at).toLocaleDateString() : ''}</div>
              </div>
            ))}
          </div>
        </div>
      )}

      {loading && (
        <div style={{ textAlign: 'center', padding: 40, color: '#333' }}>Loading dashboard...</div>
      )}
    </div>
  )
}
