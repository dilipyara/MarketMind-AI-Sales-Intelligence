// src/pages/HistoryPage.jsx
import { useState, useEffect } from 'react'
import { analyticsAPI } from '../utils/api'
import { MODULES } from '../utils/moduleConfig'

export default function HistoryPage() {
  const [recent, setRecent] = useState([])
  const [analytics, setAnalytics] = useState(null)
  const [loading, setLoading] = useState(true)
  const [selected, setSelected] = useState(null)

  useEffect(() => {
    Promise.all([analyticsAPI.recent(50), analyticsAPI.summary()])
      .then(([rec, sum]) => {
        setRecent(rec.recent_activity || [])
        setAnalytics(sum)
      })
      .finally(() => setLoading(false))
  }, [])

  return (
    <div style={{ padding: '32px 36px' }}>
      <div style={{ marginBottom: 28 }}>
        <h1 style={{ fontSize: 22, fontWeight: 900, margin: 0, letterSpacing: -0.5 }}>Activity History</h1>
        <p style={{ fontSize: 13, color: '#555', margin: '6px 0 0' }}>All AI-generated outputs stored in MongoDB</p>
      </div>

      {/* Module Usage Stats */}
      {analytics && (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: 10, marginBottom: 28 }}>
          {MODULES.map(m => {
            const key = {
              campaign: 'campaigns', pitch: 'pitches', lead: 'leads', market: 'market_analysis',
              strategy: 'strategies', persona: 'personas', multimodal: 'multimodal',
              report: 'reports', predict: 'predictions', compete: 'competitive_intel'
            }[m.id]
            const count = analytics.module_breakdown?.[key]?.total_outputs || 0
            return (
              <div key={m.id} style={{ background: '#0D0D1A', border: '1px solid #15152A', borderRadius: 12, padding: '12px 14px' }}>
                <div style={{ fontSize: 16, marginBottom: 6 }}>{m.icon}</div>
                <div style={{ fontSize: 18, fontWeight: 800, color: m.color }}>{count}</div>
                <div style={{ fontSize: 10, color: '#444', marginTop: 2 }}>{m.label}</div>
              </div>
            )
          })}
        </div>
      )}

      {/* Activity List */}
      <div style={{ background: '#0D0D1A', border: '1px solid #15152A', borderRadius: 16, overflow: 'hidden' }}>
        <div style={{ padding: '14px 20px', borderBottom: '1px solid #111', fontSize: 11, fontWeight: 700, color: '#333', letterSpacing: 1.5 }}>
          RECENT OUTPUTS ({recent.length})
        </div>
        {loading ? (
          <div style={{ padding: 40, textAlign: 'center', color: '#333' }}>Loading history...</div>
        ) : recent.length === 0 ? (
          <div style={{ padding: 40, textAlign: 'center', color: '#333' }}>No history yet. Generate some AI outputs!</div>
        ) : (
          recent.map((r, i) => {
            const mod = MODULES.find(m => m.label === r.module)
            return (
              <div key={i}
                onClick={() => setSelected(selected === i ? null : i)}
                style={{
                  padding: '14px 20px', borderBottom: i < recent.length - 1 ? '1px solid #0d0d15' : 'none',
                  cursor: 'pointer', transition: 'background 0.15s',
                  background: selected === i ? '#15152A' : 'transparent',
                }}
                onMouseEnter={e => { if (selected !== i) e.currentTarget.style.background = '#0f0f1a' }}
                onMouseLeave={e => { if (selected !== i) e.currentTarget.style.background = 'transparent' }}
              >
                <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                  <span style={{ fontSize: 18 }}>{mod?.icon || '🤖'}</span>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: 12, fontWeight: 700, color: mod?.color || '#888' }}>{r.module}</div>
                    <div style={{ fontSize: 11, color: '#444', marginTop: 2 }}>{r.input_preview}</div>
                  </div>
                  <div style={{ fontSize: 10, color: '#333' }}>
                    {r.created_at ? new Date(r.created_at).toLocaleString() : ''}
                  </div>
                  <span style={{ fontSize: 10, color: '#333' }}>{selected === i ? '▲' : '▼'}</span>
                </div>
              </div>
            )
          })
        )}
      </div>
    </div>
  )
}
