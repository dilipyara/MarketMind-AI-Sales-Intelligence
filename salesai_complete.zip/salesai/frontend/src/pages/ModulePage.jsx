// src/pages/ModulePage.jsx
import { useState, useRef } from 'react'
import { useParams } from 'react-router-dom'
import { getModule } from '../utils/moduleConfig'
import * as apis from '../utils/api'
import toast from 'react-hot-toast'
import ReactMarkdown from 'react-markdown'

const API_MAP = {
  campaign: { fn: (d) => apis.campaignAPI.generate(d) },
  pitch: { fn: (d) => apis.pitchAPI.generate(d) },
  lead: { fn: (d) => apis.leadAPI.score(d) },
  market: { fn: (d) => apis.marketAPI.analyze(d) },
  strategy: { fn: (d) => apis.strategyAPI.generate(d) },
  persona: { fn: (d) => apis.personaAPI.generate(d) },
  multimodal: { fn: (d) => apis.multimodalAPI.generate(d) },
  report: { fn: (d) => apis.reportAPI.generate(d) },
  predict: { fn: (d) => apis.predictAPI.generate(d) },
  compete: { fn: (d) => apis.competeAPI.analyze(d) },
}

export default function ModulePage() {
  const { moduleId } = useParams()
  const module = getModule(moduleId)
  const [formData, setFormData] = useState({})
  const [result, setResult] = useState(null)
  const [loading, setLoading] = useState(false)
  const outputRef = useRef(null)

  if (!module) return <div style={{ padding: 40, color: '#444' }}>Module not found</div>

  const handleChange = (name, value) => {
    setFormData(prev => ({ ...prev, [name]: value }))
  }

  const handleSubmit = async () => {
    // Validate required fields
    const missing = module.fields.filter(f => f.required && !formData[f.name])
    if (missing.length > 0) {
      toast.error(`Please fill in: ${missing.map(f => f.label).join(', ')}`)
      return
    }

    setLoading(true)
    setResult(null)

    // Merge defaults
    const payload = {}
    module.fields.forEach(f => {
      const val = formData[f.name]
      if (val !== undefined && val !== '') {
        payload[f.name] = f.type === 'number' ? parseInt(val) : val
      } else if (f.default !== undefined) {
        payload[f.name] = f.type === 'number' ? parseInt(f.default) : f.default
      }
    })

    try {
      const res = await API_MAP[moduleId].fn(payload)
      setResult(res)
      toast.success('AI output generated!')
      setTimeout(() => outputRef.current?.scrollIntoView({ behavior: 'smooth' }), 100)
    } catch (err) {
      toast.error(err.message || 'Generation failed')
    } finally {
      setLoading(false)
    }
  }

  const handleCopy = () => {
    if (result?.output) {
      navigator.clipboard.writeText(result.output)
      toast.success('Copied to clipboard!')
    }
  }

  return (
    <div style={{ padding: '32px 36px', maxWidth: 900 }}>
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 14, marginBottom: 28 }}>
        <div style={{
          width: 52, height: 52, borderRadius: 14, fontSize: 26,
          background: `${module.color}18`, border: `1px solid ${module.color}33`,
          display: 'flex', alignItems: 'center', justifyContent: 'center'
        }}>{module.icon}</div>
        <div>
          <h1 style={{ fontSize: 22, fontWeight: 900, margin: 0, letterSpacing: -0.5 }}>{module.label}</h1>
          <p style={{ fontSize: 13, color: '#555', margin: '4px 0 0' }}>{module.description}</p>
        </div>
        <div style={{ marginLeft: 'auto', height: 2, flex: 1, background: `linear-gradient(90deg, ${module.color}44, transparent)`, borderRadius: 2 }} />
      </div>

      {/* Form */}
      <div style={{ background: '#0D0D1A', border: '1px solid #15152A', borderRadius: 16, padding: 28, marginBottom: 24 }}>
        <div style={{ fontSize: 11, fontWeight: 700, color: '#333', letterSpacing: 2, marginBottom: 20 }}>INPUT PARAMETERS</div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 16 }}>
          {module.fields.map(field => (
            <div key={field.name} style={{ gridColumn: field.type === 'textarea' ? '1 / -1' : 'auto' }}>
              <label style={{ display: 'block', fontSize: 11, fontWeight: 600, color: '#555', marginBottom: 6, letterSpacing: 0.5 }}>
                {field.label} {field.required && <span style={{ color: module.color }}>*</span>}
              </label>

              {field.type === 'textarea' ? (
                <textarea
                  value={formData[field.name] || ''}
                  onChange={e => handleChange(field.name, e.target.value)}
                  placeholder={field.placeholder}
                  rows={3}
                  style={inputStyle()}
                />
              ) : field.type === 'select' ? (
                <select
                  value={formData[field.name] || field.default || ''}
                  onChange={e => handleChange(field.name, e.target.value)}
                  style={inputStyle()}
                >
                  {field.options.map(opt => (
                    <option key={opt} value={opt}>{opt.charAt(0).toUpperCase() + opt.slice(1).replace(/_/g, ' ')}</option>
                  ))}
                </select>
              ) : (
                <input
                  type={field.type}
                  value={formData[field.name] || ''}
                  onChange={e => handleChange(field.name, e.target.value)}
                  placeholder={field.placeholder}
                  style={inputStyle()}
                />
              )}
            </div>
          ))}
        </div>

        <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: 20, gap: 10 }}>
          <button onClick={() => { setFormData({}); setResult(null) }}
            style={{ padding: '10px 18px', borderRadius: 9, border: '1px solid #1e1e3a', background: 'transparent', color: '#555', fontSize: 13, cursor: 'pointer' }}>
            Clear
          </button>
          <button onClick={handleSubmit} disabled={loading}
            style={{
              padding: '10px 28px', borderRadius: 9, border: 'none', cursor: loading ? 'not-allowed' : 'pointer',
              background: loading ? '#1a1a2e' : `linear-gradient(135deg, ${module.color}, ${module.color}bb)`,
              color: loading ? '#444' : '#000', fontWeight: 700, fontSize: 13, transition: 'all 0.2s',
            }}>
            {loading ? '⏳ Generating...' : `✨ Generate ${module.label}`}
          </button>
        </div>
      </div>

      {/* Lead Score Card */}
      {result && module.hasScore && (
        <div style={{ background: '#0D0D1A', border: `1px solid ${module.color}33`, borderRadius: 16, padding: 24, marginBottom: 20, display: 'grid', gridTemplateColumns: 'auto 1fr', gap: 24, alignItems: 'center' }}>
          <div style={{ textAlign: 'center' }}>
            <div style={{ fontSize: 52, fontWeight: 900, color: scoreColor(result.score) }}>{result.score}</div>
            <div style={{ fontSize: 10, color: '#444', marginTop: 2 }}>LEAD SCORE</div>
            <div style={{ marginTop: 8, padding: '4px 12px', borderRadius: 20, background: scoreColor(result.score) + '20', color: scoreColor(result.score), fontSize: 12, fontWeight: 700 }}>
              {result.priority}
            </div>
          </div>
          <div>
            <div style={{ fontSize: 18, fontWeight: 800, color: '#fff', marginBottom: 4 }}>{result.conversion_probability} Conversion</div>
            <p style={{ fontSize: 13, color: '#888', margin: '0 0 12px', lineHeight: 1.6 }}>{result.reasoning}</p>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
              {(result.next_actions || []).map((action, i) => (
                <span key={i} style={{ fontSize: 11, padding: '4px 10px', borderRadius: 6, background: '#15152A', color: '#aaa', border: '1px solid #1e1e2e' }}>
                  {i + 1}. {action}
                </span>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Output */}
      {result?.output && (
        <div ref={outputRef} style={{ background: '#0D0D1A', border: `1px solid ${module.color}22`, borderRadius: 16, overflow: 'hidden' }}>
          <div style={{ padding: '14px 20px', borderBottom: '1px solid #111', display: 'flex', alignItems: 'center', justifyContent: 'space-between', background: module.color + '08' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <div style={{ width: 6, height: 6, borderRadius: '50%', background: module.color, boxShadow: `0 0 6px ${module.color}` }} />
              <span style={{ fontSize: 11, fontWeight: 700, color: module.color, letterSpacing: 1.5 }}>AI OUTPUT</span>
            </div>
            <div style={{ display: 'flex', gap: 8 }}>
              <button onClick={handleCopy}
                style={{ padding: '5px 14px', borderRadius: 6, border: '1px solid #1e1e3a', background: 'transparent', color: '#666', fontSize: 11, cursor: 'pointer' }}>
                📋 Copy
              </button>
              {result.record_id && (
                <span style={{ fontSize: 10, color: '#333', display: 'flex', alignItems: 'center' }}>ID: {result.record_id.slice(-8)}</span>
              )}
            </div>
          </div>
          <div style={{ padding: '24px 28px', maxHeight: 600, overflowY: 'auto' }}>
            <div className="markdown-output" style={{ color: '#ccc', fontSize: 13, lineHeight: 1.8 }}>
              <ReactMarkdown>{result.output}</ReactMarkdown>
            </div>
          </div>
        </div>
      )}

      <style>{`
        .markdown-output h2 { color: #fff; font-size: 15px; margin: 20px 0 8px; font-weight: 800; }
        .markdown-output h3 { color: #ddd; font-size: 14px; margin: 16px 0 6px; font-weight: 700; }
        .markdown-output p { color: #ccc; margin: 6px 0; }
        .markdown-output ul, .markdown-output ol { padding-left: 20px; color: #aaa; }
        .markdown-output li { margin: 4px 0; }
        .markdown-output strong { color: #fff; }
        .markdown-output table { width: 100%; border-collapse: collapse; margin: 12px 0; }
        .markdown-output th { background: #15152A; padding: 8px 12px; text-align: left; font-size: 11px; color: #888; }
        .markdown-output td { padding: 8px 12px; border-bottom: 1px solid #111; font-size: 12px; color: #ccc; }
        textarea { resize: vertical; }
        select option { background: #0D0D1A; }
      `}</style>
    </div>
  )
}

function inputStyle() {
  return {
    width: '100%', background: '#070710', border: '1px solid #1e1e3a',
    borderRadius: 9, padding: '11px 14px', color: '#ddd', fontSize: 13,
    outline: 'none', boxSizing: 'border-box', fontFamily: 'inherit', lineHeight: 1.5,
  }
}

function scoreColor(score) {
  if (score >= 75) return '#00D4AA'
  if (score >= 50) return '#FFD93D'
  return '#FF6B6B'
}
