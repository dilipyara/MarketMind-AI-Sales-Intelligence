// src/utils/api.js - Axios API Client
import axios from 'axios'

const api = axios.create({
  baseURL: '/api',
  timeout: 60000,
  headers: { 'Content-Type': 'application/json' }
})

// Response interceptor for error handling
api.interceptors.response.use(
  res => res.data,
  err => {
    const msg = err.response?.data?.detail || 'An error occurred'
    return Promise.reject(new Error(msg))
  }
)

// ─── API Calls ─────────────────────────────────────────────────────────────
export const campaignAPI = {
  generate: (data) => api.post('/campaign/generate', data),
  history: (limit = 10) => api.get(`/campaign/history?limit=${limit}`),
}

export const pitchAPI = {
  generate: (data) => api.post('/pitch/generate', data),
  history: (limit = 10) => api.get(`/pitch/history?limit=${limit}`),
}

export const leadAPI = {
  score: (data) => api.post('/lead/score', data),
  history: (limit = 10) => api.get(`/lead/history?limit=${limit}`),
}

export const marketAPI = {
  analyze: (data) => api.post('/market/analyze', data),
  history: (limit = 10) => api.get(`/market/history?limit=${limit}`),
}

export const strategyAPI = {
  generate: (data) => api.post('/strategy/generate', data),
  history: (limit = 10) => api.get(`/strategy/history?limit=${limit}`),
}

export const personaAPI = {
  generate: (data) => api.post('/persona/generate', data),
  history: (limit = 10) => api.get(`/persona/history?limit=${limit}`),
}

export const reportAPI = {
  generate: (data) => api.post('/report/generate', data),
  history: (limit = 10) => api.get(`/report/history?limit=${limit}`),
}

export const predictAPI = {
  generate: (data) => api.post('/predict/generate', data),
  history: (limit = 10) => api.get(`/predict/history?limit=${limit}`),
}

export const competeAPI = {
  analyze: (data) => api.post('/compete/analyze', data),
  history: (limit = 10) => api.get(`/compete/history?limit=${limit}`),
}

export const multimodalAPI = {
  generate: (data) => api.post('/multimodal/generate', data),
  history: (limit = 10) => api.get(`/multimodal/history?limit=${limit}`),
}

export const analyticsAPI = {
  summary: () => api.get('/analytics/summary'),
  recent: (limit = 20) => api.get(`/analytics/recent?limit=${limit}`),
}

export default api
