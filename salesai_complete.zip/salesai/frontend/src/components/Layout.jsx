// src/components/Layout.jsx
import { Outlet, NavLink, useLocation } from 'react-router-dom'
import { MODULES } from '../utils/moduleConfig'

export default function Layout() {
  const location = useLocation()

  return (
    <div style={{ display: 'flex', minHeight: '100vh', background: '#080810', fontFamily: "'DM Sans', 'Segoe UI', sans-serif", color: '#fff' }}>
      {/* Sidebar */}
      <aside style={{
        width: 240, flexShrink: 0, background: '#0A0A16',
        borderRight: '1px solid #15152A', display: 'flex', flexDirection: 'column',
        position: 'fixed', top: 0, left: 0, height: '100vh', overflowY: 'auto', zIndex: 50
      }}>
        {/* Logo */}
        <div style={{ padding: '20px 16px 16px', borderBottom: '1px solid #15152A' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <div style={{
              width: 36, height: 36, borderRadius: 10,
              background: 'linear-gradient(135deg, #FF6B35, #7B61FF)',
              display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 18
            }}>⚡</div>
            <div>
              <div style={{ fontSize: 14, fontWeight: 800, letterSpacing: -0.3 }}>SalesAI</div>
              <div style={{ fontSize: 10, color: '#444', marginTop: 1 }}>Intelligence Platform</div>
            </div>
          </div>
        </div>

        {/* Nav */}
        <nav style={{ padding: '12px 8px', flex: 1 }}>
          <NavLink to="/" end style={({ isActive }) => navStyle(isActive, '#61D4FF')}>
            <span>🏠</span> <span>Dashboard</span>
          </NavLink>

          <div style={{ fontSize: 9, fontWeight: 700, color: '#2a2a4a', letterSpacing: 2, padding: '16px 8px 8px' }}>MODULES</div>

          {MODULES.map(m => (
            <NavLink
              key={m.id}
              to={`/module/${m.id}`}
              style={({ isActive }) => navStyle(isActive, m.color)}
            >
              <span style={{ fontSize: 15 }}>{m.icon}</span>
              <span style={{ fontSize: 12 }}>{m.label}</span>
            </NavLink>
          ))}

          <div style={{ fontSize: 9, fontWeight: 700, color: '#2a2a4a', letterSpacing: 2, padding: '16px 8px 8px' }}>MORE</div>
          <NavLink to="/history" style={({ isActive }) => navStyle(isActive, '#888')}>
            <span>🕐</span> <span style={{ fontSize: 12 }}>History</span>
          </NavLink>
        </nav>

        {/* Footer */}
        <div style={{ padding: '12px 16px', borderTop: '1px solid #15152A' }}>
          <div style={{ fontSize: 10, color: '#2a2a4a' }}>Powered by Groq + FastAPI</div>
          <div style={{ display: 'flex', gap: 6, marginTop: 6 }}>
            <span style={{ fontSize: 9, padding: '2px 6px', borderRadius: 4, background: '#00D4AA15', color: '#00D4AA', border: '1px solid #00D4AA22' }}>LIVE</span>
            <span style={{ fontSize: 9, padding: '2px 6px', borderRadius: 4, background: '#7B61FF15', color: '#7B61FF', border: '1px solid #7B61FF22' }}>v1.0</span>
          </div>
        </div>
      </aside>

      {/* Main */}
      <main style={{ flex: 1, marginLeft: 240, minHeight: '100vh', overflowY: 'auto' }}>
        <Outlet />
      </main>
    </div>
  )
}

function navStyle(isActive, color) {
  return {
    display: 'flex', alignItems: 'center', gap: 10,
    padding: '9px 10px', borderRadius: 9, marginBottom: 2,
    textDecoration: 'none', transition: 'all 0.15s',
    background: isActive ? `${color}12` : 'transparent',
    borderLeft: `3px solid ${isActive ? color : 'transparent'}`,
    color: isActive ? color : '#555',
    fontWeight: isActive ? 700 : 500,
  }
}
