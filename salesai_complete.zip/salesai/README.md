# ⚡ GenAI Sales & Marketing Intelligence Platform

> AI-powered platform for sales and marketing teams using **Groq LLM + FastAPI + React + MongoDB**

---

## 🏗️ Tech Stack

| Layer | Technology |
|-------|-----------|
| **Frontend** | React 18 + Vite + React Router |
| **Backend** | Python FastAPI |
| **AI Engine** | Groq API (llama3-70b-8192) |
| **Database** | MongoDB (via Motor async driver) |
| **Deployment** | Docker Compose |

---

## 📦 Project Structure

```
salesai/
├── backend/
│   ├── main.py              # FastAPI app entry point
│   ├── config.py            # Environment settings
│   ├── database.py          # MongoDB connection
│   ├── models/
│   │   └── schemas.py       # Pydantic request/response models
│   ├── services/
│   │   ├── groq_service.py  # Core Groq AI service
│   │   └── storage_service.py # MongoDB CRUD operations
│   ├── routes/
│   │   ├── campaign.py      # Campaign generation
│   │   ├── pitch.py         # Sales pitch creation
│   │   ├── lead.py          # Lead scoring & insights
│   │   ├── market.py        # Market analysis
│   │   ├── strategy.py      # Business strategy
│   │   ├── persona.py       # Customer persona generation
│   │   ├── multimodal.py    # Multimodal content suggestions
│   │   ├── report.py        # Performance reports
│   │   ├── predict.py       # Predictive insights
│   │   ├── compete.py       # Competitive intelligence
│   │   └── analytics.py     # Usage analytics dashboard
│   ├── requirements.txt
│   ├── Dockerfile
│   └── .env.example
├── frontend/
│   ├── src/
│   │   ├── App.jsx           # Root with routing
│   │   ├── main.jsx          # Entry point
│   │   ├── components/
│   │   │   └── Layout.jsx    # Sidebar + main layout
│   │   ├── pages/
│   │   │   ├── Dashboard.jsx # Overview + analytics
│   │   │   ├── ModulePage.jsx# Dynamic module UI
│   │   │   └── HistoryPage.jsx # MongoDB history
│   │   ├── utils/
│   │   │   ├── api.js        # Axios API client
│   │   │   └── moduleConfig.js # Module registry + forms
│   │   └── styles/
│   │       └── global.css
│   ├── index.html
│   ├── package.json
│   └── vite.config.js
└── docker-compose.yml
```

---

## 🚀 Quick Start

### Option 1: Docker (Recommended)

```bash
# 1. Clone the project
git clone <your-repo> && cd salesai

# 2. Set your Groq API key
echo "GROQ_API_KEY=your_key_here" > .env

# 3. Start everything
docker-compose up -d

# App runs at: http://localhost:3000
# API docs at: http://localhost:8000/docs
```

### Option 2: Manual Setup

#### Backend
```bash
cd backend

# Create virtual environment
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt

# Set up environment
cp .env.example .env
# Edit .env with your GROQ_API_KEY

# Start MongoDB (or use MongoDB Atlas)
# mongod --dbpath ./data

# Run the server
uvicorn main:app --reload --port 8000
```

#### Frontend
```bash
cd frontend

# Install dependencies
npm install

# Start dev server
npm run dev
# Runs at http://localhost:3000
```

---

## 🔑 Environment Variables

```env
# backend/.env
GROQ_API_KEY=gsk_...           # Get from https://console.groq.com
GROQ_MODEL=llama3-70b-8192     # Best model for business tasks
MONGODB_URL=mongodb://localhost:27017
MONGODB_DB=salesai
APP_ENV=development
SECRET_KEY=your-secret-key
```

---

## 📡 API Endpoints

| Module | Method | Endpoint |
|--------|--------|----------|
| Campaign | POST | `/api/campaign/generate` |
| Sales Pitch | POST | `/api/pitch/generate` |
| Lead Scoring | POST | `/api/lead/score` |
| Market Analysis | POST | `/api/market/analyze` |
| Business Strategy | POST | `/api/strategy/generate` |
| Customer Persona | POST | `/api/persona/generate` |
| Multimodal Content | POST | `/api/multimodal/generate` |
| Performance Report | POST | `/api/report/generate` |
| Predictive Insights | POST | `/api/predict/generate` |
| Competitive Intel | POST | `/api/compete/analyze` |
| Analytics Summary | GET | `/api/analytics/summary` |
| Recent Activity | GET | `/api/analytics/recent` |

**Swagger UI:** `http://localhost:8000/docs`

---

## 🧠 AI Modules

| # | Module | Description |
|---|--------|-------------|
| 1 | 📣 Campaign Generator | Email, social media, ad copy |
| 2 | 🎯 Sales Pitch | Cold call, demo, email outreach |
| 3 | 📊 Lead Scoring | Score (0-100), priority, next actions |
| 4 | 📈 Market Analysis | Trends, opportunities, risks |
| 5 | 🧩 Business Strategy | Growth & revenue optimization |
| 6 | 👤 Customer Persona | Synthetic buyer profiles |
| 7 | 🎨 Multimodal Content | Visual ads, video scripts |
| 8 | 📋 Performance Report | KPIs, insights, improvements |
| 9 | 🔮 Predictive Insights | Sales forecasts, segment predictions |
| 10 | ⚔️ Competitive Intel | Battle cards, differentiation strategy |

---

## 📊 Additional Features Added

- ✅ **Analytics Dashboard** — Usage stats across all modules
- ✅ **MongoDB Persistence** — All outputs saved and retrievable
- ✅ **History Page** — Browse past AI outputs
- ✅ **Structured Lead Scoring** — JSON score + narrative report
- ✅ **Docker Compose** — One-command deployment
- ✅ **Swagger API Docs** — Auto-generated at /docs

---

## 🔧 Get Your Groq API Key

1. Go to [https://console.groq.com](https://console.groq.com)
2. Sign up / log in
3. Create a new API key
4. Add to your `.env` file as `GROQ_API_KEY=gsk_...`

Groq is **free** with generous rate limits and extremely fast inference.
